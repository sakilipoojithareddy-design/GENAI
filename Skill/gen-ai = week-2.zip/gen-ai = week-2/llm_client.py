
from abc import ABC, abstractmethod
from google import genai
import requests


class LLMProvider(ABC):

    @abstractmethod
    def generate(self, prompt):
        pass


class GeminiProvider(LLMProvider):

    def __init__(self, api_key):
        self.client = genai.Client(api_key=api_key)

    def generate(self, prompt):
        response = self.client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )
        return response.text


class OllamaProvider(LLMProvider):

    def __init__(self, model="qwen2.5:0.5b"):
        self.model = model
        self.url = "http://localhost:11434/api/generate"

    def generate(self, prompt):
        response = requests.post(
            self.url,
            json={
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {"num_ctx": 1024}
            },
            timeout=120
        )

        response.raise_for_status()
        return response.json()["response"]


class LLMClient:

    def __init__(self, provider):
        self.provider = provider

    def generate(self, prompt):
        return self.provider.generate(prompt)
