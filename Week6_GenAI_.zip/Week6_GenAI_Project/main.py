import csv
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
GOLDEN_SET = BASE_DIR / "golden_set.json"
RESULTS_CSV = BASE_DIR / "baseline_results.csv"

def find_ollama():
    """Find the Ollama executable on Windows, macOS, or Linux."""
    executable = shutil.which("ollama")
    if executable:
        return executable

    if os.name == "nt":
        local_app_data = os.environ.get("LOCALAPPDATA", "")
        candidates = [
            Path(local_app_data) / "Programs" / "Ollama" / "ollama.exe",
            Path("C:/Program Files/Ollama/ollama.exe"),
        ]
        for candidate in candidates:
            if candidate.is_file():
                return str(candidate)

    return None

def evaluate_answer(expected, answer):
    """Calculate keyword overlap between expected and generated answers."""
    keywords = set(re.findall(r"\\b[a-zA-Z]{4,}\\b", expected.lower()))
    answer_words = set(re.findall(r"\\b[a-zA-Z]{4,}\\b", answer.lower()))
    matched = keywords.intersection(answer_words)
    return (len(matched) / len(keywords) * 100) if keywords else 0.0

def main():
    if not GOLDEN_SET.is_file():
        print(f"Error: {GOLDEN_SET.name} was not found.")
        sys.exit(1)

    ollama = find_ollama()
    if not ollama:
        print("Error: Ollama was not found. Install Ollama and make sure it is on PATH.")
        sys.exit(1)

    try:
        with GOLDEN_SET.open("r", encoding="utf-8") as file:
            questions = json.load(file)
    except (json.JSONDecodeError, OSError) as error:
        print(f"Could not read {GOLDEN_SET.name}: {error}")
        sys.exit(1)

    results = []

    for item in questions:
        question = item["question"]
        expected = item["expected_answer"]
        print(f"\\nQuestion: {question}")

        try:
            result = subprocess.run(
                [ollama, "run", "llama3.2", question],
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=180,
                check=False,
            )
        except subprocess.TimeoutExpired:
            print("Ollama request timed out; skipping this question.")
            continue

        if result.returncode != 0:
            print("Ollama error:", result.stderr.strip())
            continue

        answer = result.stdout.strip()
        score = evaluate_answer(expected, answer)

        print("Answer:", answer)
        print("Score:", round(score, 2), "%")

        results.append({
            "question": question,
            "expected_answer": expected,
            "generated_answer": answer,
            "score": round(score, 2),
        })

    with RESULTS_CSV.open("w", newline="", encoding="utf-8") as file:
        fieldnames = [
            "question",
            "expected_answer",
            "generated_answer",
            "score",
        ]
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

    print("\\nEvaluation completed!")
    print(f"Results saved in {RESULTS_CSV.name}")

if __name__ == "__main__":
    main()
